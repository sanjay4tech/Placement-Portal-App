from flask import Flask, redirect, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix

from models import db, bootstrap_admin
from routes.auth_routes import auth_bp
from routes.admin_routes import admin_bp
from routes.company_routes import company_bp
from routes.student_routes import student_bp


def create_app():
    """Application factory for the Placement Portal."""
    # instance_relative_config=True tells Flask that instance/ is special
    app = Flask(__name__, instance_relative_config=True)

    # Secret key for sessions & flash
    app.config["SECRET_KEY"] = "change-this-secret-key-in-production"

    # Build an absolute SQLite path inside the instance folder
    # app.instance_path is an absolute path like: C:/.../Placement-Portal-App/instance
    db_file = app.instance_path.replace("\\", "/") + "/portal.sqlite3"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + db_file
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Resume uploads (relative to project root; folder must exist)
    app.config["UPLOAD_FOLDER"] = "static/uploads"

    # Init SQLAlchemy
    db.init_app(app)

    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(company_bp)
    app.register_blueprint(student_bp)

    # Optional proxy fix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)

    # Ensure DB and default admin exist
    with app.app_context():
        db.create_all()
        bootstrap_admin()

    # Index route defined here so it uses this app
    @app.route("/")
    def index():
        role = session.get("active_role")
        if role == "admin":
            return redirect(url_for("admin_views.admin_home"))
        if role == "company":
            return redirect(url_for("company_views.company_home"))
        if role == "student":
            return redirect(url_for("student_views.student_home"))
        return redirect(url_for("auth_views.sign_in"))

    return app


if __name__ == "__main__":
    # Create the Flask app and run it
    placement_app = create_app()
    placement_app.run(debug=True)