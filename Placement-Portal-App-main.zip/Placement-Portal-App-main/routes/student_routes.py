from functools import wraps
from datetime import datetime, date

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)

from models import (
    db,
    StudentUser,
    StudentProfile,
    PlacementDrive,
    CompanyAccount,
    Application,
)

student_bp = Blueprint("student_views", __name__, url_prefix="/student")


def student_required(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        if session.get("active_role") != "student":
            flash("Student access required.", "danger")
            return redirect(url_for("auth_views.sign_in"))
        student_id = session.get("user_id")
        student = StudentUser.query.get(student_id)
        if not student or student.account_status == "blacklisted":
            flash("Your account is not active.", "danger")
            return redirect(url_for("auth_views.sign_in"))
        return view_func(student, *args, **kwargs)

    return wrapper


@student_bp.route("/home")
@student_required
def student_home(student):
    today = date.today()

    approved_drives = (
        PlacementDrive.query.join(CompanyAccount)
        .filter(
            PlacementDrive.drive_status == "approved",
            PlacementDrive.application_deadline >= today,
            CompanyAccount.approval_state == "approved",
            CompanyAccount.account_state == "active",
        )
        .order_by(PlacementDrive.application_deadline.asc())
        .all()
    )

    applied_drive_ids = {app.drive_id for app in student.applications}

    recent_applications = (
        Application.query.filter_by(student_id=student.id)
        .order_by(Application.applied_on.desc())
        .limit(10)
        .all()
    )

    # template: templates/student_dashboard.html
    return render_template(
        "student_dashboard.html",
        student=student,
        approved_drives=approved_drives,
        applied_drive_ids=applied_drive_ids,
        recent_applications=recent_applications,
    )


@student_bp.route("/profile", methods=["GET", "POST"])
@student_required
def profile(student):
    profile = student.profile

    if request.method == "POST":
        student.full_name = request.form.get("full_name", student.full_name)
        student.phone_number = request.form.get(
            "phone_number", student.phone_number
        )
        student.department = request.form.get("department", student.department)

        cgpa = request.form.get("cgpa", "").strip()
        try:
            student.cgpa = float(cgpa) if cgpa else None
        except ValueError:
            pass

        profile.skills = request.form.get("skills", profile.skills)
        profile.about_me = request.form.get("about_me", profile.about_me)
        profile.linkedin_url = request.form.get(
            "linkedin_url", profile.linkedin_url
        )

        resume_file = request.files.get("resume_file")
        if resume_file and resume_file.filename:
            filename = resume_file.filename.replace(" ", "_")
            save_path = current_app.config["UPLOAD_FOLDER"] + "/" + filename
            resume_file.save(save_path)
            profile.resume_filename = filename

        db.session.commit()
        flash("Profile updated successfully.", "success")
        return redirect(url_for("student_views.profile"))

    # template: templates/profile.html
    return render_template(
        "profile.html",
        student=student,
        profile=profile,
    )


@student_bp.route("/resume/<filename>")
@student_required
def resume_download(student, filename):
    return send_from_directory(
        current_app.config["UPLOAD_FOLDER"], filename, as_attachment=True
    )


@student_bp.route("/apply/<int:drive_id>", methods=["POST"])
@student_required
def apply_drive(student, drive_id):
    drive = PlacementDrive.query.get_or_404(drive_id)

    if drive.drive_status != "approved":
        flash("You can apply only to approved drives.", "warning")
        return redirect(url_for("student_views.student_home"))

    if drive.application_deadline < date.today():
        flash("Application deadline has passed.", "warning")
        return redirect(url_for("student_views.student_home"))

    existing = Application.query.filter_by(
        student_id=student.id,
        drive_id=drive.id,
    ).first()
    if existing:
        flash("You have already applied to this drive.", "info")
        return redirect(url_for("student_views.student_home"))

    note = request.form.get("student_note", "").strip()

    application = Application(
        student_id=student.id,
        drive_id=drive.id,
        current_status="Applied",
        student_note=note,
    )
    db.session.add(application)
    db.session.commit()

    flash("Application submitted.", "success")
    return redirect(url_for("student_views.student_home"))


@student_bp.route("/history")
@student_required
def application_history(student):
    """Full history of applications."""
    all_applications = (
        db.session.query(Application, PlacementDrive, CompanyAccount)
        .join(PlacementDrive, Application.drive_id == PlacementDrive.id)
        .join(CompanyAccount, PlacementDrive.company_id == CompanyAccount.id)
        .filter(Application.student_id == student.id)
        .order_by(Application.applied_on.desc())
        .all()
    )

    return render_template(
        "placement_history.html",
        student=student,
        application_rows=all_applications,
    )