from functools import wraps

from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from models import (
    db,
    AdminUser,
    StudentUser,
    CompanyAccount,
    PlacementDrive,
    Application,
)

admin_bp = Blueprint("admin_views", __name__, url_prefix="/admin")


def admin_required(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        if session.get("active_role") != "admin":
            flash("Admin access required.", "danger")
            return redirect(url_for("auth_views.sign_in"))
        admin_id = session.get("user_id")
        admin = AdminUser.query.get(admin_id)
        if not admin or not admin.is_active:
            flash("Admin account is inactive.", "danger")
            return redirect(url_for("auth_views.sign_in"))
        return view_func(*args, **kwargs)

    return wrapper


@admin_bp.route("/home")
@admin_required
def admin_home():
    total_students = StudentUser.query.count()
    total_companies = CompanyAccount.query.count()
    total_drives = PlacementDrive.query.count()
    total_applications = Application.query.count()

    pending_companies = CompanyAccount.query.filter_by(approval_state="pending").all()
    pending_drives = PlacementDrive.query.filter_by(drive_status="pending").all()

    # template: templates/admin_dashboard.html
    return render_template(
        "admin_dashboard.html",
        total_students=total_students,
        total_companies=total_companies,
        total_drives=total_drives,
        total_applications=total_applications,
        pending_companies=pending_companies,
        pending_drives=pending_drives,
    )


@admin_bp.route("/companies")
@admin_required
def manage_companies():
    search = request.args.get("q", "").strip()
    query = CompanyAccount.query
    if search:
        like = f"%{search}%"
        query = query.filter(
            CompanyAccount.company_name.ilike(like)
            | CompanyAccount.contact_email.ilike(like)
        )
    companies = query.order_by(CompanyAccount.created_at.desc()).all()
    # template: templates/admin_companies.html
    return render_template("admin_companies.html", companies=companies)


@admin_bp.route("/companies/<int:company_id>/set_state", methods=["POST"])
@admin_required
def update_company_state(company_id):
    company = CompanyAccount.query.get_or_404(company_id)

    new_approval = request.form.get("approval_state")
    new_account_state = request.form.get("account_state")

    if new_approval in {"pending", "approved", "rejected"}:
        company.approval_state = new_approval

    if new_account_state in {"active", "blacklisted"}:
        company.account_state = new_account_state

    db.session.commit()
    flash("Company status updated.", "success")
    return redirect(url_for("admin_views.manage_companies"))


@admin_bp.route("/students")
@admin_required
def manage_students():
    search = request.args.get("q", "").strip()
    query = StudentUser.query
    if search:
        like = f"%{search}%"
        query = query.filter(
            StudentUser.full_name.ilike(like)
            | StudentUser.email.ilike(like)
            | StudentUser.phone_number.ilike(like)
        )
    students = query.order_by(StudentUser.created_at.desc()).all()
    # template: templates/admin_students.html
    return render_template("admin_students.html", students=students)


@admin_bp.route("/students/<int:student_id>/set_state", methods=["POST"])
@admin_required
def update_student_state(student_id):
    student = StudentUser.query.get_or_404(student_id)
    new_state = request.form.get("account_status")
    if new_state in {"active", "blacklisted"}:
        student.account_status = new_state
        db.session.commit()
        flash("Student status updated.", "success")
    return redirect(url_for("admin_views.manage_students"))


@admin_bp.route("/drives")
@admin_required
def manage_drives():
    drives = (
        PlacementDrive.query.join(CompanyAccount)
        .add_entity(CompanyAccount)
        .order_by(PlacementDrive.created_at.desc())
        .all()
    )
    # template: templates/admin_drives.html
    return render_template("admin_drives.html", drives=drives)


@admin_bp.route("/drives/<int:drive_id>/set_state", methods=["POST"])
@admin_required
def update_drive_state(drive_id):
    drive = PlacementDrive.query.get_or_404(drive_id)
    new_status = request.form.get("drive_status")
    if new_status in {"pending", "approved", "closed"}:
        drive.drive_status = new_status
        db.session.commit()
        flash("Drive status updated.", "success")
    else:
        flash("Invalid status value.", "warning")
    return redirect(url_for("admin_views.manage_drives"))


@admin_bp.route("/applications")
@admin_required
def view_applications():
    applications = (
        Application.query.join(StudentUser)
        .join(PlacementDrive)
        .join(CompanyAccount)
        .add_entity(StudentUser)
        .add_entity(PlacementDrive)
        .add_entity(CompanyAccount)
        .order_by(Application.applied_on.desc())
        .all()
    )
    # template: templates/admin_applications.html
    return render_template("admin_applications.html", applications=applications)