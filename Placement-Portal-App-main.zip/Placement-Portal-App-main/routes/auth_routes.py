from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

from models import db, AdminUser, StudentUser, StudentProfile, CompanyAccount

auth_bp = Blueprint("auth_views", __name__, url_prefix="/auth")


def _clear_login_state():
    session.pop("user_id", None)
    session.pop("active_role", None)


@auth_bp.route("/signin", methods=["GET", "POST"])
def sign_in():
    """Login for Admin, Student, and Company."""
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip().lower()
        password = request.form.get("password", "")

        # Admin login (username)
        admin = AdminUser.query.filter_by(username=identifier).first()
        if admin and admin.is_active and check_password_hash(
            admin.password_hash, password
        ):
            _clear_login_state()
            session["user_id"] = admin.id
            session["active_role"] = "admin"
            flash("Logged in as Admin.", "success")
            return redirect(url_for("admin_views.admin_home"))

        # Student login (email)
        student = StudentUser.query.filter_by(email=identifier).first()
        if student and check_password_hash(student.password_hash, password):
            if student.account_status == "blacklisted":
                flash("Your student account is blacklisted.", "danger")
            else:
                _clear_login_state()
                session["user_id"] = student.id
                session["active_role"] = "student"
                flash("Logged in as Student.", "success")
                return redirect(url_for("student_views.student_home"))

        # Company login (email)
        company = CompanyAccount.query.filter_by(contact_email=identifier).first()
        if company and check_password_hash(company.password_hash, password):
            if company.approval_state != "approved":
                flash("Company is not approved yet.", "warning")
            elif company.account_state == "blacklisted":
                flash("Company account is blacklisted.", "danger")
            else:
                _clear_login_state()
                session["user_id"] = company.id
                session["active_role"] = "company"
                flash("Logged in as Company.", "success")
                return redirect(url_for("company_views.company_home"))

        flash("Invalid login details.", "danger")

    # standalone template: templates/login.html
    return render_template("login.html")


@auth_bp.route("/signout")
def sign_out():
    _clear_login_state()
    flash("Logged out.", "info")
    return redirect(url_for("auth_views.sign_in"))


@auth_bp.route("/register/student", methods=["GET", "POST"])
def register_student():
    """Student registration."""
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        department = request.form.get("department", "").strip()
        cgpa_str = request.form.get("cgpa", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not full_name or not email or not phone or not password:
            flash("Name, email, phone and password are required.", "warning")
            return redirect(url_for("auth_views.register_student"))

        if password != confirm:
            flash("Passwords do not match.", "warning")
            return redirect(url_for("auth_views.register_student"))

        if StudentUser.query.filter_by(email=email).first():
            flash("Email already registered.", "warning")
            return redirect(url_for("auth_views.register_student"))

        if StudentUser.query.filter_by(phone_number=phone).first():
            flash("Phone already registered.", "warning")
            return redirect(url_for("auth_views.register_student"))

        try:
            cgpa_value = float(cgpa_str) if cgpa_str else None
        except ValueError:
            cgpa_value = None

        student = StudentUser(
            full_name=full_name,
            email=email,
            phone_number=phone,
            department=department,
            cgpa=cgpa_value,
            password_hash=generate_password_hash(password),
        )
        db.session.add(student)
        db.session.flush()

        profile = StudentProfile(student_id=student.id)
        db.session.add(profile)
        db.session.commit()

        flash("Student registered successfully. Please login.", "success")
        return redirect(url_for("auth_views.sign_in"))

    # standalone template: templates/register_student.html
    return render_template("register_student.html")


@auth_bp.route("/register/company", methods=["GET", "POST"])
def register_company():
    """Company registration (requires admin approval before login)."""
    if request.method == "POST":
        company_name = request.form.get("company_name", "").strip()
        contact_person = request.form.get("contact_person", "").strip()
        contact_email = request.form.get("contact_email", "").strip().lower()
        contact_phone = request.form.get("contact_phone", "").strip()
        website_url = request.form.get("website_url", "").strip()
        description = request.form.get("description", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not company_name or not contact_email or not password:
            flash("Company name, email and password are required.", "warning")
            return redirect(url_for("auth_views.register_company"))

        if password != confirm:
            flash("Passwords do not match.", "warning")
            return redirect(url_for("auth_views.register_company"))

        if CompanyAccount.query.filter_by(contact_email=contact_email).first():
            flash("This email is already registered.", "warning")
            return redirect(url_for("auth_views.register_company"))

        company = CompanyAccount(
            company_name=company_name,
            contact_person=contact_person,
            contact_email=contact_email,
            contact_phone=contact_phone,
            website_url=website_url,
            description=description,
            password_hash=generate_password_hash(password),
            approval_state="pending",
            account_state="active",
        )
        db.session.add(company)
        db.session.commit()

        flash("Company registered. Wait for admin approval.", "success")
        return redirect(url_for("auth_views.sign_in"))

    # standalone template: templates/register_company.html
    return render_template("register_company.html")