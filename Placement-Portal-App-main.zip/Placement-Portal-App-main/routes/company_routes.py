from functools import wraps
from datetime import datetime

from flask import (
    Blueprint,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from models import db, CompanyAccount, PlacementDrive, Application, StudentUser

company_bp = Blueprint("company_views", __name__, url_prefix="/company")


def company_required(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        if session.get("active_role") != "company":
            flash("Company access required.", "danger")
            return redirect(url_for("auth_views.sign_in"))

        company_id = session.get("user_id")
        company = CompanyAccount.query.get(company_id)
        if not company:
            flash("Company account not found.", "danger")
            return redirect(url_for("auth_views.sign_in"))
        if company.approval_state != "approved":
            flash("Company must be approved by admin.", "warning")
            return redirect(url_for("auth_views.sign_in"))
        if company.account_state == "blacklisted":
            flash("Company account is blacklisted.", "danger")
            return redirect(url_for("auth_views.sign_in"))

        return view_func(company, *args, **kwargs)

    return wrapper


@company_bp.route("/home")
@company_required
def company_home(company):
    drives = PlacementDrive.query.filter_by(company_id=company.id).order_by(
        PlacementDrive.created_at.desc()
    ).all()
    app_counts = {d.id: len(d.applications) for d in drives}
    # template: templates/company_dashboard.html
    return render_template(
        "company_dashboard.html",
        company=company,
        drives=drives,
        application_counts=app_counts,
    )


@company_bp.route("/drives/new", methods=["GET", "POST"])
@company_required
def create_drive(company):
    if request.method == "POST":
        drive_title = request.form.get("drive_title", "").strip()
        job_role = request.form.get("job_role", "").strip()
        job_location = request.form.get("job_location", "").strip()
        salary_package = request.form.get("salary_package", "").strip()
        job_description = request.form.get("job_description", "").strip()
        eligibility_criteria = request.form.get("eligibility_criteria", "").strip()
        deadline_str = request.form.get("application_deadline", "").strip()

        if not drive_title or not job_role or not job_description or not deadline_str:
            flash("Title, role, description and deadline are required.", "warning")
            return redirect(url_for("company_views.create_drive"))

        try:
            deadline_date = datetime.strptime(deadline_str, "%Y-%m-%d").date()
        except ValueError:
            flash("Deadline must be in YYYY-MM-DD format.", "warning")
            return redirect(url_for("company_views.create_drive"))

        drive = PlacementDrive(
            company_id=company.id,
            drive_title=drive_title,
            job_role=job_role,
            job_location=job_location,
            salary_package=salary_package,
            job_description=job_description,
            eligibility_criteria=eligibility_criteria,
            application_deadline=deadline_date,
            drive_status="pending",
        )
        db.session.add(drive)
        db.session.commit()
        flash("Drive created and sent for admin approval.", "success")
        return redirect(url_for("company_views.company_home"))

    # template: templates/create_drive.html
    return render_template("create_drive.html", company=company)


@company_bp.route("/drives/<int:drive_id>")
@company_required
def drive_details(company, drive_id):
    drive = PlacementDrive.query.filter_by(
        id=drive_id, company_id=company.id
    ).first_or_404()
    applications = (
        Application.query.filter_by(drive_id=drive.id)
        .join(StudentUser)
        .add_entity(StudentUser)
        .order_by(Application.applied_on.desc())
        .all()
    )
    # template: templates/drive_details.html
    return render_template(
        "drive_details.html",
        company=company,
        drive=drive,
        applications=applications,
    )


@company_bp.route("/drives/<int:drive_id>/edit", methods=["GET", "POST"])
@company_required
def edit_drive(company, drive_id):
    drive = PlacementDrive.query.filter_by(
        id=drive_id, company_id=company.id
    ).first_or_404()

    if request.method == "POST":
        action = request.form.get("action", "update")

        if action == "close":
            drive.drive_status = "closed"
        else:
            drive.drive_title = request.form.get("drive_title", drive.drive_title)
            drive.job_role = request.form.get("job_role", drive.job_role)
            drive.job_location = request.form.get(
                "job_location", drive.job_location
            )
            drive.salary_package = request.form.get(
                "salary_package", drive.salary_package
            )
            drive.job_description = request.form.get(
                "job_description", drive.job_description
            )
            drive.eligibility_criteria = request.form.get(
                "eligibility_criteria", drive.eligibility_criteria
            )
            deadline_str = request.form.get("application_deadline", "").strip()
            if deadline_str:
                try:
                    drive.application_deadline = datetime.strptime(
                        deadline_str, "%Y-%m-%d"
                    ).date()
                except ValueError:
                    flash("Invalid deadline format.", "warning")

        db.session.commit()
        flash("Drive updated.", "success")
        return redirect(url_for("company_views.drive_details", drive_id=drive.id))

    # template: templates/edit_drive.html
    return render_template("edit_drive.html", company=company, drive=drive)


@company_bp.route("/applications/<int:application_id>/review", methods=["POST"])
@company_required
def review_application(company, application_id):
    application = (
        Application.query.join(PlacementDrive)
        .filter(
            Application.id == application_id,
            PlacementDrive.company_id == company.id,
        )
        .first_or_404()
    )

    new_status = request.form.get("status")
    remark = request.form.get("remark", "").strip()

    valid_status = {
        "Applied",
        "Shortlisted",
        "Interview",
        "Selected",
        "Rejected",
        "Placed",
    }

    if new_status in valid_status:
        application.current_status = new_status
        application.recruiter_remark = remark
        application.last_updated = datetime.utcnow()
        db.session.commit()
        flash("Application updated.", "success")
    else:
        flash("Invalid status value.", "warning")

    return redirect(
        url_for("company_views.drive_details", drive_id=application.drive_id)
    )