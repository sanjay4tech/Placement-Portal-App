Placement Portal Application (MAD-I)

Flask + SQLite based placement portal with Admin, Company and Student roles.
